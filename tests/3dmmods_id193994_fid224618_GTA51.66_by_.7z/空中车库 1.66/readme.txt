------- Change Log -------

Change Log
Version 0.6
- Removed NetNotifications
- Fixed crashing. Hopefully everything works again.

Version 0.5
- Now uses ScriptHookVDotNet 2.3
- Added support for latest GTA V Updates (Up to build 463)
- You can now change the radio station by going to the red circle in your Garage.
- Fixed neon color bug

Version 0.41
- Fixed numerous bugs

Version 0.4
- Stats work ;)
- Liveries now save.
- Fixed not being able to set vehicle mods to stock.
- Increased size of Vehicle Stats floater.
- Garage Blips are now short ranged. (Won't clutter the map)
- Added support for "ILL-GOTTEN GAINS PART 1" DLC Vehicles
- Added Experimental Garage Layout Editor (Be careful with this, it's not fully complete)
- Added support for 2 Car and 6 Car Garage Interiors
- Added "Return all Vehicles" to mechanic menu
- Added Several Garages scattered over the city (7 New Ones)
- You now have to press the Action Button to enter and leave Garages.
- Active vehicles can now be delivered if you're far away enough from them.
- You can no longer enter your Garage while wanted. (Unless your Wanted stars are flashing)
- Delivered Vehicles now align to the road properly.
- Added "For Sale" signs at the font of each Building for purchasing Garages.
- You can now purchase Garages. (Garages with Vehicles already in them will be given to you for free)
- Added Net Notifications and analytics.

Version 0.31
Compatibility for ScriptHookVDotNet 1.0

Version 0.3
- Added Weazel Plaza
- Added Tinsel Towers
- Fixed numerous bugs preventing Vehicles from Spawning.
- Fixed bug when player exits a vehicle from slot 2, when slot 1 is empty, it causes a crash.
- Changed error log layout again.
- Display Vehicles are now removed (internally) when leaving the garage (Persistance mod compatibility)
- Vehicle blip hides when you're in the vehicle.
- In-Garage Los Santos Customs Overhaul (Not entirely finished though)
- If Vehicles are moved inside Garage, they are reset back to their original position.
- Script now checks every tick if a Vehicle is missing due to a spawn glitch, and tries to spawn it.
- Added Vehicle list to Floor select menu.
- Fixed plate types not saving

Version 0.2
- Added Colour options to the in garage Mod Shop (RGB, non of that predefined Colours stuff)
- Changed up Mod Shop UI
- Added vehicle delivery (Press F5) You can change this in the SPG.ini file.
- Bug Logging.
- Remove Vehicle Confirmation.
- Remove Vehicle from Garage and drive it outside.
- Some bug fixes.
- Removed yellow highlight.

Version 0.1
- First Release
- Store Vehicles in Garage
- Share vehicle saves with friends
- Mod vehicle in garage
- +More


Known Issues:
- Vehicles that don't have a roof, have a roof when loading.

------- Installation -------

1. Install ScriptHookV (http://www.dev-c.com/gtav/scripthookv/) 
2. Install ScriptHookVDotNet (https://github.com/crosire/scripthookvdotnet/releases/tag/v2.9) 
3. Copy the Scripts folder in this zip, to your GTA V Directory. 
4. Run GTA V 

----- Troubleshooting -----

Make sure you download and install these first:

https://www.microsoft.com/en-us/download/details.aspx?id=40784
https://www.microsoft.com/en-us/download/details.aspx?id=30653
Enjoy!

----------------------------
